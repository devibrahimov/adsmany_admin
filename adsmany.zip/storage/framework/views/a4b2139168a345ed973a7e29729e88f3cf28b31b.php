<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="row">
        <!-- Basic Table -->
        <div class="row mt-25 mb-20">
            <div class="col-md-3 col-xs-12 mt-15">
                <a href="<?php echo e(route('newProgram')); ?>" class="btn btn-info btn-rounded btn-block btn-anim">
                    <i class="fa fa-pencil"></i>
                    <span class="btn-text">Yeni Program Əlavə Et</span>
                </a>
            </div>
        </div>


        <div class="col-sm-12">
            <div class="panel panel-default border-panel card-view">
                <div class="panel-heading">
                    <div class="pull-left">
                        <h6 class="panel-title txt-dark">Tv Kanallar</h6>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="panel-wrapper collapse in">
                    <div class="panel-body">
                        <div class="table-wrap mt-40">
                            <div class="table-responsive">
                                <table class="table mb-0">
                                    <thead>
                                    <tr>
                                        <th>#ID</th>
                                        <th>Tv Kanal</th>
                                        <th>Rəsim</th>
                                        <th>Program </th>
                                        <th>Əməliyyatlar</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($program->id); ?></td>
                                            <td><?php echo e($program->channel->country->name); ?></td>
                                            <td>
                                                <img src="<?php echo e($program->image); ?>" width="70px" alt="">
                                            </td>
                                            <td><?php echo e($program->name); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('ChannelEdit',$program->id)); ?>" class="label label-danger"><i class="fa fa-pencil"> </i> Redaktə Et</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Basic Table -->
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\adsmany\resources\views/pages/programs/dashboard.blade.php ENDPATH**/ ?>