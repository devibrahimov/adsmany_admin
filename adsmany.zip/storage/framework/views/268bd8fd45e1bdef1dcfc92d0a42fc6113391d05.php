<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12 col-md-5">
            <div class="panel panel-default border-panel card-view">
                <div class="panel-heading">
                    <div class="pull-left">
                        <h6 class="panel-title txt-dark">Basic Form</h6>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="panel-wrapper collapse in">
                    <div class="panel-body">
                        <div class="form-wrap">
                            <form action="<?php echo e(route('LangEdit',$lang->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label class="control-label mb-10 text-left">Dilin kodu (hər dilkodu dünyaca qəbul edilmiş şəkildə yazın)</label>
                                    <input type="text" class="form-control"  name="code" value="<?php echo e($lang->code); ?>">
                                </div>
                                <div class="form-group">
                                    <label class="control-label mb-10 text-left"  >Dil (hər dili öz dlində yazın)</label>
                                    <input type="text"  name="name" class="form-control" value="<?php echo e($lang->name); ?>" >
                                </div>
                                <button type="submit" class="btn btn-info btn-rounded btn-block btn-anim">
                                    <i class="fa fa-plus"></i>
                                    <span class="btn-text">Əlavə Et</span>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\adsmany\resources\views/pages/languages/edit.blade.php ENDPATH**/ ?>