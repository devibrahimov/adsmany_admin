<?php

namespace App\Http\Controllers;

use App\Models\Language;
use App\Models\ProgramSerial;
use App\Models\TvChannel;
use Illuminate\Http\Request;

class ProgramsSerialsController extends Controller
{
     public function dashborad(){
         $programs = ProgramSerial::join('programs_serials_langcontent','programs_serials.id','=','programs_serials_langcontent.programs_serials_id')
             ->where('lang','az')->get();
         return view('pages.programs.dashboard',compact(['programs']));
     }

     public function create(){
         $languages = Language::all();
         $channels = TvChannel::join('tvchannel_content','tv_channels.id','=','tvchannel_content.channel_id')->where('lang','az')->get();

         return view('pages.programs.create',compact(['channels','languages']));
     }

     public function store(Request $request){

     }

     public function edit($id){

     }

     public function update($id,Request $request){

     }
}
